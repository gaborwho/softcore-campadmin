﻿namespace AdminFelulet.IfjusagiVezeto
{
    partial class CamperList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNev = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonMentes = new System.Windows.Forms.Button();
            this.textBoxElerhetosegek = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxBetegsegek = new System.Windows.Forms.TextBox();
            this.textBoxMegjegyzesek = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.listBoxTaborozok = new System.Windows.Forms.ListBox();
            this.tbTörlés = new System.Windows.Forms.Button();
            this.btImport = new System.Windows.Forms.Button();
            this.buttonUjTaborozo = new System.Windows.Forms.Button();
            this.buttonRendeles = new System.Windows.Forms.Button();
            this.dtpSzul = new System.Windows.Forms.DateTimePicker();
            this.tbOrszag = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBoxNev
            // 
            this.textBoxNev.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxNev.Location = new System.Drawing.Point(358, 12);
            this.textBoxNev.Name = "textBoxNev";
            this.textBoxNev.Size = new System.Drawing.Size(159, 20);
            this.textBoxNev.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(325, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Név";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(288, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Születési év";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(312, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Ország";
            // 
            // buttonMentes
            // 
            this.buttonMentes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMentes.Location = new System.Drawing.Point(439, 314);
            this.buttonMentes.Name = "buttonMentes";
            this.buttonMentes.Size = new System.Drawing.Size(78, 23);
            this.buttonMentes.TabIndex = 15;
            this.buttonMentes.Text = "Mentés";
            this.buttonMentes.UseVisualStyleBackColor = true;
            this.buttonMentes.Click += new System.EventHandler(this.buttonMentes_Click);
            // 
            // textBoxElerhetosegek
            // 
            this.textBoxElerhetosegek.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxElerhetosegek.Location = new System.Drawing.Point(358, 91);
            this.textBoxElerhetosegek.Multiline = true;
            this.textBoxElerhetosegek.Name = "textBoxElerhetosegek";
            this.textBoxElerhetosegek.Size = new System.Drawing.Size(159, 61);
            this.textBoxElerhetosegek.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(277, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "Elérhetőségek";
            // 
            // textBoxBetegsegek
            // 
            this.textBoxBetegsegek.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxBetegsegek.Location = new System.Drawing.Point(358, 158);
            this.textBoxBetegsegek.Multiline = true;
            this.textBoxBetegsegek.Name = "textBoxBetegsegek";
            this.textBoxBetegsegek.Size = new System.Drawing.Size(159, 61);
            this.textBoxBetegsegek.TabIndex = 26;
            // 
            // textBoxMegjegyzesek
            // 
            this.textBoxMegjegyzesek.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMegjegyzesek.Location = new System.Drawing.Point(358, 225);
            this.textBoxMegjegyzesek.Multiline = true;
            this.textBoxMegjegyzesek.Name = "textBoxMegjegyzesek";
            this.textBoxMegjegyzesek.Size = new System.Drawing.Size(159, 50);
            this.textBoxMegjegyzesek.TabIndex = 27;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(288, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "Betegségek";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(277, 228);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = "Megjegyzések";
            // 
            // listBoxTaborozok
            // 
            this.listBoxTaborozok.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxTaborozok.FormattingEnabled = true;
            this.listBoxTaborozok.IntegralHeight = false;
            this.listBoxTaborozok.Location = new System.Drawing.Point(12, 12);
            this.listBoxTaborozok.Name = "listBoxTaborozok";
            this.listBoxTaborozok.Size = new System.Drawing.Size(259, 325);
            this.listBoxTaborozok.TabIndex = 30;
            this.listBoxTaborozok.SelectedIndexChanged += new System.EventHandler(this.listBoxTaborozok_SelectedIndexChanged);
            // 
            // tbTörlés
            // 
            this.tbTörlés.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tbTörlés.Location = new System.Drawing.Point(358, 314);
            this.tbTörlés.Name = "tbTörlés";
            this.tbTörlés.Size = new System.Drawing.Size(75, 23);
            this.tbTörlés.TabIndex = 32;
            this.tbTörlés.Text = "Törlés";
            this.tbTörlés.UseVisualStyleBackColor = true;
            this.tbTörlés.Click += new System.EventHandler(this.tbTörlés_Click);
            // 
            // btImport
            // 
            this.btImport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btImport.Location = new System.Drawing.Point(280, 314);
            this.btImport.Name = "btImport";
            this.btImport.Size = new System.Drawing.Size(72, 23);
            this.btImport.TabIndex = 33;
            this.btImport.Text = "Importálás";
            this.btImport.UseVisualStyleBackColor = true;
            this.btImport.Click += new System.EventHandler(this.btImport_Click);
            // 
            // buttonUjTaborozo
            // 
            this.buttonUjTaborozo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonUjTaborozo.Location = new System.Drawing.Point(280, 285);
            this.buttonUjTaborozo.Name = "buttonUjTaborozo";
            this.buttonUjTaborozo.Size = new System.Drawing.Size(72, 23);
            this.buttonUjTaborozo.TabIndex = 34;
            this.buttonUjTaborozo.Text = "Új";
            this.buttonUjTaborozo.UseVisualStyleBackColor = true;
            this.buttonUjTaborozo.Click += new System.EventHandler(this.buttonUjTaborozo_Click);
            // 
            // buttonRendeles
            // 
            this.buttonRendeles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonRendeles.Location = new System.Drawing.Point(358, 285);
            this.buttonRendeles.Name = "buttonRendeles";
            this.buttonRendeles.Size = new System.Drawing.Size(159, 23);
            this.buttonRendeles.TabIndex = 35;
            this.buttonRendeles.Text = "Csoporhoz/Szobához rendelés";
            this.buttonRendeles.UseVisualStyleBackColor = true;
            this.buttonRendeles.Click += new System.EventHandler(this.buttonRendeles_Click);
            // 
            // dtpSzul
            // 
            this.dtpSzul.Location = new System.Drawing.Point(358, 41);
            this.dtpSzul.Name = "dtpSzul";
            this.dtpSzul.Size = new System.Drawing.Size(159, 20);
            this.dtpSzul.TabIndex = 36;
            // 
            // tbOrszag
            // 
            this.tbOrszag.Location = new System.Drawing.Point(358, 65);
            this.tbOrszag.Name = "tbOrszag";
            this.tbOrszag.Size = new System.Drawing.Size(159, 20);
            this.tbOrszag.TabIndex = 37;
            // 
            // CamperList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 349);
            this.Controls.Add(this.tbOrszag);
            this.Controls.Add(this.dtpSzul);
            this.Controls.Add(this.buttonRendeles);
            this.Controls.Add(this.buttonUjTaborozo);
            this.Controls.Add(this.btImport);
            this.Controls.Add(this.tbTörlés);
            this.Controls.Add(this.listBoxTaborozok);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxMegjegyzesek);
            this.Controls.Add(this.textBoxBetegsegek);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxElerhetosegek);
            this.Controls.Add(this.textBoxNev);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonMentes);
            this.Name = "CamperList";
            this.Text = "Táborozók";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxNev;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonMentes;
        private System.Windows.Forms.TextBox textBoxElerhetosegek;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxBetegsegek;
        private System.Windows.Forms.TextBox textBoxMegjegyzesek;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBoxTaborozok;
        private System.Windows.Forms.Button tbTörlés;
        private System.Windows.Forms.Button btImport;
        private System.Windows.Forms.Button buttonUjTaborozo;
        private System.Windows.Forms.Button buttonRendeles;
        private System.Windows.Forms.DateTimePicker dtpSzul;
        private System.Windows.Forms.TextBox tbOrszag;

    }
}