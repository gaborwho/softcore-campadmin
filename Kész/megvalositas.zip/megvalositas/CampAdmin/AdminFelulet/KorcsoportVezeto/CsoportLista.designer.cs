﻿namespace AdminFelulet.KorcsoportVezeto
{
    partial class CsoportLista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonMentes = new System.Windows.Forms.Button();
            this.comboBoxIfi2 = new System.Windows.Forms.ComboBox();
            this.comboBoxIfi1 = new System.Windows.Forms.ComboBox();
            this.textBoxNev = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbcsoportok = new System.Windows.Forms.ListBox();
            this.buttonTorles = new System.Windows.Forms.Button();
            this.cbKorcsoport = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btModosit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonMentes
            // 
            this.buttonMentes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMentes.Location = new System.Drawing.Point(424, 205);
            this.buttonMentes.Name = "buttonMentes";
            this.buttonMentes.Size = new System.Drawing.Size(75, 23);
            this.buttonMentes.TabIndex = 0;
            this.buttonMentes.Text = "Mentés";
            this.buttonMentes.UseVisualStyleBackColor = true;
            this.buttonMentes.Click += new System.EventHandler(this.buttonMentes_Click);
            // 
            // comboBoxIfi2
            // 
            this.comboBoxIfi2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxIfi2.FormattingEnabled = true;
            this.comboBoxIfi2.Location = new System.Drawing.Point(373, 65);
            this.comboBoxIfi2.Name = "comboBoxIfi2";
            this.comboBoxIfi2.Size = new System.Drawing.Size(126, 21);
            this.comboBoxIfi2.TabIndex = 14;
            // 
            // comboBoxIfi1
            // 
            this.comboBoxIfi1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxIfi1.FormattingEnabled = true;
            this.comboBoxIfi1.Location = new System.Drawing.Point(373, 38);
            this.comboBoxIfi1.Name = "comboBoxIfi1";
            this.comboBoxIfi1.Size = new System.Drawing.Size(126, 21);
            this.comboBoxIfi1.TabIndex = 13;
            // 
            // textBoxNev
            // 
            this.textBoxNev.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxNev.Location = new System.Drawing.Point(373, 12);
            this.textBoxNev.Name = "textBoxNev";
            this.textBoxNev.Size = new System.Drawing.Size(126, 20);
            this.textBoxNev.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(340, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Név";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(280, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "2. Ifjúsági vezető";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(280, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "1. Ifjúsági vezető";
            // 
            // lbcsoportok
            // 
            this.lbcsoportok.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbcsoportok.FormattingEnabled = true;
            this.lbcsoportok.IntegralHeight = false;
            this.lbcsoportok.Location = new System.Drawing.Point(12, 12);
            this.lbcsoportok.Name = "lbcsoportok";
            this.lbcsoportok.Size = new System.Drawing.Size(185, 193);
            this.lbcsoportok.TabIndex = 15;
            // 
            // buttonTorles
            // 
            this.buttonTorles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonTorles.Location = new System.Drawing.Point(343, 205);
            this.buttonTorles.Name = "buttonTorles";
            this.buttonTorles.Size = new System.Drawing.Size(75, 23);
            this.buttonTorles.TabIndex = 16;
            this.buttonTorles.Text = "Törlés";
            this.buttonTorles.UseVisualStyleBackColor = true;
            this.buttonTorles.Click += new System.EventHandler(this.buttonTorles_Click);
            // 
            // cbKorcsoport
            // 
            this.cbKorcsoport.FormattingEnabled = true;
            this.cbKorcsoport.Location = new System.Drawing.Point(281, 92);
            this.cbKorcsoport.Name = "cbKorcsoport";
            this.cbKorcsoport.Size = new System.Drawing.Size(218, 21);
            this.cbKorcsoport.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(217, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Korcsoport";
            // 
            // btModosit
            // 
            this.btModosit.Location = new System.Drawing.Point(255, 205);
            this.btModosit.Name = "btModosit";
            this.btModosit.Size = new System.Drawing.Size(82, 23);
            this.btModosit.TabIndex = 19;
            this.btModosit.Text = "Modosítás";
            this.btModosit.UseVisualStyleBackColor = true;
            this.btModosit.Click += new System.EventHandler(this.btModosit_Click);
            // 
            // CsoportLista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(511, 239);
            this.Controls.Add(this.btModosit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbKorcsoport);
            this.Controls.Add(this.buttonTorles);
            this.Controls.Add(this.lbcsoportok);
            this.Controls.Add(this.comboBoxIfi2);
            this.Controls.Add(this.comboBoxIfi1);
            this.Controls.Add(this.textBoxNev);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonMentes);
            this.Name = "CsoportLista";
            this.Text = "Csoportok";
            this.Load += new System.EventHandler(this.CsoportLista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonMentes;
        private System.Windows.Forms.ComboBox comboBoxIfi2;
        private System.Windows.Forms.ComboBox comboBoxIfi1;
        private System.Windows.Forms.TextBox textBoxNev;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbcsoportok;
        private System.Windows.Forms.Button buttonTorles;
        private System.Windows.Forms.ComboBox cbKorcsoport;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btModosit;
    }
}